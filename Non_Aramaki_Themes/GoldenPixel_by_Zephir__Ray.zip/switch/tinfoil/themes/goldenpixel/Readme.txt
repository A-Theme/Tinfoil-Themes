Hello this is Ray,

this is a Tinfoil theme based on the Homescreen theme of the Nintendo switch by Zephir (Graphics). The colours of the Logo and the Interface made by me.

Theme - GoldenPixel by Zephir and Ray